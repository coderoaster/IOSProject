//
//  getList.swift
//  GAMBAS
//
//  Created by SSB on 18/09/2020.
//  Copyright © 2020 TJ. All rights reserved.
//

import Foundation
