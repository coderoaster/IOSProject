//
//  DBModelPriority.swift
//  ProjectDraw
//
//  Created by SSB on 10/09/2020.
//  Copyright © 2020 SSB. All rights reserved.
//

import Foundation

class DBModelPriority: NSObject {
    
    var user_email: String?
    var user_password: String?
    var user_profilename: String?
    var user_priority: String?
    
    override init() {
        
    }
    
}
