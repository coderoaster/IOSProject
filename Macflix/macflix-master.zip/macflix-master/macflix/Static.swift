//
//  Static.swift
//  KNNTest
//
//  Created by Changsu Lee on 2020/09/08.
//  Copyright © 2020 Changsu Lee. All rights reserved.
//

import Foundation
let URL_PATH = "http://localhost:8080/Macflix/"

let USER_DEFAULT_AUTO_LOGIN_SEQ = "auto login seq string"
let USER_DEFAULT_QUERY_STATE = "query state int"

let QUERY = 0
let PRIORITY_QUERY = 1

var LOGGED_IN_SEQ = 0
var LOGGED_IN_PROFILENAME = ""
var LOGGED_IN_HEARTLIST: [Int] = []
